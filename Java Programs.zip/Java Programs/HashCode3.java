class HashCode3
{
int i;
HashCode3(int i)
{
this.i=i;
}
public String toString()
{
return i+" ";
}
public int hashCode()
{
return i;
}
public static void main(String args[])
{
HashCode3 h1=new HashCode3(20);
HashCode3 h2=new HashCode3(21);
System.out.println(h1);
System.out.println(h2);
}
}