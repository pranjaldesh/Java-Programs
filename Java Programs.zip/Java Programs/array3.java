//3D Array Program
class Array
{
public static void main(String args[])
{
int[][][] a=new int[3][][];
a[0]=new int[2][];
a[1]=new int[3][];
a[2]=new int[2][];
a[0][0]=new int[2];
a[0][1]=new int[2];
a[1][0]=new int[2];
a[1][1]=new int[1];
a[1][2]=new int[2];
a[2]=new int[2][2];
a[0][0][0]=10;
a[0][0][1]=20;
a[0][1][0]=30;
a[0][1][1]=40;
a[1][0][0]=50;
a[1][0][1]=60;
a[1][1][0]=70;
a[1][2][0]=80;
a[2][0][0]=90;
a[2][0][1]=95;
a[2][1][0]=96;
a[2][1][1]=97;

for(int i=0;i<a.length;i++)
{
for(int j=0;j<a.length;j++)
{
for(int k=0;k<a.length;k++)
{
System.out.println(a[i][j][k]);
}
}
}
}
}