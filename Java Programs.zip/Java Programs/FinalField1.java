class FinalField1
{
final int a;
{
a=100;
}
System.out.println("a="+a);
}
