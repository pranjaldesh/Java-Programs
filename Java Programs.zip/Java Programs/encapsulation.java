class Address
{
private String city;
public void set_city(String city)
{
this.city=city;
}
public String get_city()
{
return this.city;
}
}
class Student
{
private String name;
public void set_name(String name)
{
this.name=name;
}
public void goingToCollege(Bike b)
{
System.out.println
}
public String get_name()
{
return this.name;
}
Address ad=new Address();
ad.set_city(Akole);
String g=ad.get_city();
}
}
class Bike
{
private String bikename;
public void setBikename(String bikename)
{
this.bikename=bikename;
}
public String getBikename()
{
return this.bikename;
}
}
class Private
{
public Static void main()
{
Student s=new Student();
Bike b=new Bike();
b.set_bikename("Activa");
String x=b.get_Bikename();
s.goingToCollegeby(b)

}
}