class DemoFrame
{
	DemoFrame()
	{
		java.awt.Frame frame=new java.awt.Frame();
		frame.setBackground(java.awt.Color.RED);
		frame.setVisible(true);
		frame.setTitle("Login Page");
		frame.setSize(500,500);
		frame.setLocation(400,100);	
	}	
}
class TestFrame1
{
	public static void main(String args[])
	{
		DemoFrame dframe=new DemoFrame();
	}
}