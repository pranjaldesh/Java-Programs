class DemoJframe
{
	DemoJframe()
	{
		javax.swing.JFrame frame=new javax.swing.JFrame();
		frame.getContentPane().setBackground(java.awt.Color.RED);
		frame.setVisible(true);
		frame.setTitle("Login Page");
		frame.setSize(500,500);
		frame.setLocation(400,100);
		frame.setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);	
	}	
}
class TestJframeNew
{
	public static void main(String args[])
	{
		DemoJframe dframe=new DemoJframe();
	}
}