class Fun
{
public static void main(String args[])
{
Run.main(null);
}
}