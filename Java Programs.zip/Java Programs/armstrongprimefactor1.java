//Find prime factor of armstrong number
class Table
{
public static void main(String args[])
{
int n=Integer.parseInt(args[0]);
int temp,count=0,num,num1,rem,sum=0,x;
temp=n;
while(temp>0)
{
temp=temp/10;
count++;
}
num=n;
num1=n;
while(num1>0)
{
rem=num1%10;
x=power(rem,count);
sum=sum+x;
num1=num1/10;
}
if(sum==n)
{
System.out.println("No.is armstrong number="+sum);
int i=2;
while(sum>1)
{
if(sum%i==0)
{
System.out.println(i);
sum=sum/i;
}
else
{
i++;
}
}
}
else
{
System.out.println("No.is not armstrong number");
}
}
public static int power(int n,int count)
{
int total=1;
while(count!=0)
{
total=total*n;
count--;
}
return total;
}
}