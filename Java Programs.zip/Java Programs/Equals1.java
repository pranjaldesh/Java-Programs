class Equals1
{
String name;
int age;
public
Equals1(String name,int age)
{
this.name=name;
this.age=age;
}
public boolean equals(Object obj)
{
try{
String name1=this.name;
int age1=this.age;
Equals1 s=(Equals1)obj;
String name2=s.name;
int age2=s.age;
if(name1.equals(name2)&& age1==age2)
{
return true;
}
else
{
return false;
}
}
catch(ClassCastException e)
{
return false;
}
catch(NullPointerException e)
{
return false;
}
}
public static void main(String args[])
{
Equals1 e1=new Equals1("Pranjal",1);
Equals1 e2=new Equals1("Advik",2);
Equals1 e3=e1;
Equals1 e4=new Equals1("Pranjal",1);
System.out.println(e1.equals(e2));
System.out.println(e1.equals(e3));
System.out.println(e1.equals(e4));
}
}