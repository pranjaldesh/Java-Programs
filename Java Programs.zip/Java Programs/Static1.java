class Static1
{
int sun()
{
return 200;
}
static int y=sun();
static
{
System.out.println("Good Morning");
}
public static void main(String args[])
{
System.out.println("ADVJM");
}
}