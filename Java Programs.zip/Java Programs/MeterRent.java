import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
class 	MeterRent
{
public static void main(String args[]) throws IOException
{
int unit,total=0;
System.out.println("Enter Units=");
BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
unit=Integer.parseInt(br.readLine());
System.out.println(unit);
if(unit==0)
{
System.out.println("BILL="+"150");
}
else
{
if(unit<=100)
{
total=100*3;
}
else if(unit<=200)
{
total=100*3+(unit-100)*5;
}
else if(unit<=300)
{
total=100*3+100*5+(unit-200)*7;
}
else if(unit>300)
{
total=100*3+100*5+100*7+(unit-300)*10;
}
System.out.println("BILL="+total);
}
}
}




