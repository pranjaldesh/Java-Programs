class HashCode1
{
int i;
HashCode1(int i)
{
this.i=i;
}
public static void main(String args[])
{
HashCode1 h1=new HashCode1(20);
HashCode1 h2=new HashCode1(21);
System.out.println(h1);
System.out.println(h2);
}
}



