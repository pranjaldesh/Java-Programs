//Using c.readPassword
import java.io.Console;
class ConsoleNew
{
public static void main(String args[])
{
Console c=System.console();
System.out.println("Enter Name=");
String n=c.readLine();
System.out.println(n);
System.out.println("Enter Password=");
System.out.println(c.readPassword);
}
}