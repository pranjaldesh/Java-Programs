package com.cognizant.cog;
import com.capgemini.cap;
class Company2
{
public static void main(String args[])
{
Company1.main(null);
}
}