package pack1;
import com.p2.Test;
public class Sample
{
  public static void main(String args[])
  {
   Test.main(null);
  }
}