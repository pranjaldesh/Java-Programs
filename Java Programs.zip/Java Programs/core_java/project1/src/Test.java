package com.p2;
import com.p1.Demo;
public class Test
{
public static void main(String args[])
{
Demo.main(null);
}
}