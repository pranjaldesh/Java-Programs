class StudentToString
{
String name;
int age;
StudentToString(String name,int age)
{
this.name=name;
this.age=age;
}
/*public String toString()
{
return name+"....."+age;
}*/
public static void main(String args[])
{
StudentToString s1=new StudentToString("Pranjal",20);
StudentToString s2=new StudentToString("Advik",21);
System.out.println(s1);
System.out.println(s1.toString());
}
}