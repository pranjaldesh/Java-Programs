class 	MeterRent
{
public static void main(String args[])
{
int unit;
BufferReader br=new BufferReader(new InputStreamReader(System.in));
int unit=Integer.parseInt(br.readLine());
System.out.println("Unit="+unit);
}
}