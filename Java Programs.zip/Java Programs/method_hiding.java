class Parent
{
static void m1()
{
System.out.println("Parent static method");
}
}
class Child extends Parent
{
static void m1()
{
System.out.println("Child static method");
}
public static void main(String args[])
{
Parent p=new Parent();
p.m1();
Child c=new Child();
c.m1();
Parent p1=new Child();
p1.m1();
}
}