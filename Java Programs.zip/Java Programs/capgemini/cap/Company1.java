package com.capgemini.cap;
public class Company1
{
public static void main(String args[])
{
System.out.println("Company1 Class");
}
}