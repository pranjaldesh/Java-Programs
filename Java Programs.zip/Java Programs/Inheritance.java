//Inheritance
class Person
{
private String name;
private int mob;
private String address;
public void set_name(String name)
{
this.name=name;
}
public void set_mob(int mob)
{
this.mob=mob;
}
public void set_address(String address)
{
this.address=address;
}
public String get_name()
{
return this.name;
}
public int get_mob()
{
return this.mob;
}
public String get_address()
{
return this.address;
}
}
class Student extends Person
{
int roll;
public void set_roll(int roll)
{
this.roll=roll;
}
public int get_roll()
{
return this.roll;
}
public static void main(String args[])
{
Student s=new Student();
s.set_name("Pranjal");
s.set_mob(9999);
s.set_address("Akole");
s.set_roll(24);
System.out.println("Name="+s.get_name());
System.out.println("Mob="+s.get_mob());
System.out.println("Address="+s.get_address());
System.out.println("Rollno="+s.get_roll());
}
}