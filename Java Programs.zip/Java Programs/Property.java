class Property
{
public static void main(String args[])
{
String name;
int marks,rno;
name=args[0];
marks=Integer.parseInt(args[1]);
System.out.println("Name="+name);
System.out.println("Marks="+marks);
rno=Integer.parseInt(System.getProperty("Rollno"));
System.out.println("Rollno="+rno);
}
}



