class FinalMethod
{
final void fun()
{
System.out.println("Fun Function of parent");
}
}

class FinalMethod1 extends FinalMethod
{
void fun()
{
System.out.println("Fun Function of child");
}
public static void main(String args[])
{
FinalMethod1 fm=new FinalMethod1();
fm.fun();
}
}
