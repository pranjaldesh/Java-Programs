class Demo
{
public static void m1(Object o)
{
System.out.println("Object is a Parent");
}
public static void main(String args[])
{
int i=10;
m1(i);
}
}