class Person
{
  public static void main(String args[])
  {
  Student s=new Student();
  s.setBike(Pleasure);
  s.setCity(Akole);
  }
}
class Address
{
private String city;
public static void main(String args[])
{

}
public void setCity(String c)
{
this.city=city;
}
public  String get_city()
{
return city;
}
}
class Student
{
private int city;
public static void main(String args[])
{
Address a=new Address();
a.
}
public void set_add(String s)
{
}


}
}
class Bike
{
private String;
public static void main(String args[])
{


}
}
