//Using char[]
import java.io.Console;
class Consolee
{
public static void main(String args[])
{
Console c=System.console();
System.out.println("Enter Name=");
String n=c.readLine();
System.out.println(n);
System.out.println("Enter Password=");
char[] p=c.readPassword();
System.out.println(p);
}
}