class Parent
{
void property()
{
System.out.println("parent=Investment");
}
void marry()
{
System.out.println("Parent:Laxmi");
} 
}
class Child extends Parent
{
void marry()
{
System.out.println("Child:Priyanka");
}
public static void main(String args[])
{
Parent p=new Parent();
p.marry();
Child c=new Child();
c.marry();
Parent p1=new Child();
p1.marry();
} 
}