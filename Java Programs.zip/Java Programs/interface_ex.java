class Mobile //mobile uses a sim
{
 void insert_sim(Sim s)
 {
 System.out.println("INSERTED SIM IS OF : "+s);
 s.call_rate();
 s.sms_rate();
 }
}
interface Sim
{
 void call_rate();
 void sms_rate();
}
class Jio implements Sim //jio is a sim
{
 public void call_rate()
 {
 System.out.println("JIO CALL RATE IS 344 PER ANNUM");
 }
 
 public void sms_rate()
{
System.out.println("JIO SMS RATE IS 1.5 Rs PER SMS");
 }
}
class Airtel implements Sim 
{
 public void call_rate()
 {
 System.out.println("AIRTEL CALL RATE IS 267 PER ANNUM");
 }
 
 public void sms_rate()
 {
 System.out.println("AIRTEL SMS RATE IS 1 Rs PER SMS");
 }
}
class Mobile_user 
{
 public static void main(String args[])
 {
 Mobile samsung=new Mobile(); //mobile user has a mobile
 
 samsung.insert_sim(new Jio());
 samsung.insert_sim(new Airtel());
 }
}