class HashCode2
{
int i;
HashCode2(int i)
{
this.i=i;
}
public int hashCode()
{
return i;
}
public static void main(String args[])
{
HashCode2 h1=new HashCode2(20);
HashCode2 h2=new HashCode2(21);
System.out.println(h1);
System.out.println(h2);
}
}