import java.util.Scanner;

interface BANK
{
	public abstract void acceptCardNo();
	public abstract void acceptCvv();
}
class SBI implements BANK
{
	public void acceptCardNo()
	{
		System.out.println("Card No.");
		Scanner sc=new Scanner(System.in);
		String no=sc.nextLine();
	}
	public void acceptCvv()
	{
		System.out.println("CVV No.");
		Scanner sc=new Scanner(System.in);
		int no=sc.nextInt();
	}
}
class HDFC implements BANK
{
	public void acceptCardNo()
	{
		System.out.println("Card No.");
		Scanner sc=new Scanner(System.in);
		String no=sc.nextLine();
	}
	public void acceptCvv()
	{
		System.out.println("CVV No.");
		Scanner sc=new Scanner(System.in);
		int no=sc.nextInt();
	}
}
class AMEZON
{
	void payment(BANK B)
	{
		B.acceptCardNo();
		B.acceptCvv();
		System.out.println(B+"You have sucessfully done payment");
	}
}
class USER
{
	public static void main(String args[])
	{
		AMEZON az=new AMEZON();
		az.payment(new HDFC());
		
	}
}
