class NonStatic
{
int a=10;
int x=test();
int test()
{
return 20;
}
{
System.out.println("Hello!!!");
System.out.println(a);
System.out.println(x);
}
public static void main(String args[])
{
NonStatic ns=new NonStatic();
ns.test();
System.out.println("Main Function");
System.out.println(z);
}
}