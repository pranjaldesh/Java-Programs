class Demo
{
static int x=fun();
static int fun()
{
System.out.println("Demo static function");
return 10;
}
static
{
System.out.println("Demo Static block");
}
{
System.out.println("Demo Non-Static block");
}
}
class Test extends Demo
{
public static void main(String agrs[])
{
Test t=new Test();
}
}
