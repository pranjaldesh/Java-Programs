class TestT
{
public static void main(String args[])
{
DemoD.main(null);
}
}