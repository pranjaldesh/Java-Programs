//String palindrome
class Number
{
public static void main(String args[])
{
String s;
int n=args.length;
System.out.println("No.of strings="+n);
int count=0,i,flag,j;
for(i=0;i<n;i++)
{
j=0;
flag=0;
s=args[i];
count=s.length();
System.out.println("No.of characters="+count);
while(count>0)
{
if(Character.toLowerCase(s.charAt(j))!=Character.toLowerCase(s.charAt(count-1)))
{
flag=1;
break;
}
j++;
count--;
}

if(flag==0)
{
System.out.println(s+ "\tis palindrome");
}
else
{
System.out.println(s+ "\tis not palindrome");
}

}
}
}

