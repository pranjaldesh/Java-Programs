package com.bank.sbi.homeloan;
class Package1
{
	public static void main(String args[])
	{
	  system.out.println("Package Program");
	}
}
	