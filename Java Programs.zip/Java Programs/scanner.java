import java.util.Scanner;
class Scan
{
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
System.out.println("Enter Name=");
String n=sc.nextLine();
System.out.println(n);
System.out.println("Enter RollNo.=");
int r=sc.nextInt();
System.out.println(r);
System.out.println("Enter marks=");
float m=sc.nextFloat();
System.out.println(m);
}
}