import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.Scanner;
class DemoSixSix
{
	public static void main(String args[]) throws Exception
	{

	   Connection con = null;
	   con = DriverManager.getConnection("jdbc:mysql://localhost:3306/learner","root","pranjal123");
           if(con == null)
	   {
	   System.out.println("Not Established");		
	   }
	   else
	   {
	   int count;
	   Statement st = con.createStatement();
	   Scanner sc = new Scanner(System.in);
			
		
 			System.out.print("Enter roll no of student to update: ");
			int roll = sc.nextInt();
			System.out.print("Enter new name of student: ");
			String name = sc.next();
 			String query = "update learn set name = '"+name+"' where roll= "+roll;
 			count = st.executeUpdate(query);
 			if (count == 0)
 			{
                System.out.println("error in updating data in database learner ...");
 			}
 			else
 			{
                System.out.println(count+" rows affected");
 			}
			

		}
	}
}