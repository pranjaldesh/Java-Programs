import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.Scanner;

class DemoFour
{
 public static void main(String args[]) throws Exception
 {
   com.mysql.cj.jdbc.Driver obj = new com.mysql.cj.jdbc.Driver();
		
   DriverManager.registerDriver(obj);
   Connection con = null;
   con = DriverManager.getConnection("jdbc:mysql://localhost:3306/stud","root","pranjal123");
		
   if(con == null)
   {
   System.out.println("Not Established");			
   }
   else
   {
   int count;
   Statement st = con.createStatement();
   Scanner sc=new Scanner(System.in);
   System.out.println("Enter the id of student:");
   int s1=sc.nextInt();
   String query="SELECT* from stud WHERE sid= '"+s1+"'";
   ResultSet rs=st.executeQuery(query);
   String query1="insert into stud(id,name,address,marks)values(1,'pranjal','akole',90.0),(2,'nikita','pune',98.6)";
   count=st.executeUpdate(query1);
   while(rs.next() != false)
   {
   System.out.println( rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getFloat(4));
   }
   }
}
}
