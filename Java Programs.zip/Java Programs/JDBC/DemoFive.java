import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.Scanner;
import java.sql.DriverManager;
class DemoFive
{
 public static void main(String args[]) throws Exception
 {
 Connection con=null;
 Statement st=null;
 ResultSet rs=null;
 Scanner sc=null;
 
 con=DriverManager.getConnection("jdbc:mysql://localhost:3306/stud","root","pranjal123");
 st=con.createStatement();
 sc=new Scanner(System.in);
 System.out.println("Please enter student id");
 int stud_id=sc.nextInt();
 String query="select * from stud where sid="+stud_id;
 rs=st.executeQuery(query);
 if(rs.next())
 {
  System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getFloat(4)+" ");
 }
 else
 {
 System.out.println("Record not found");
 }
 }
}