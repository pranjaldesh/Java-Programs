import com.mysql.cj.jdbc.Driver;
import java.sql.Connection;
import java.util.Scanner;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.io.FileInputStream;
import java.io.InputStream;
class JdbcImage
{
    public static void main(String args[]) throws Exception
    {
        Connection con = null;
        Scanner sc = new Scanner(System.in);
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/graduate","root","pranjal123");
        if(con == null)
        {
            System.out.println("Connection Not Established...");
        }
        else
        {
            String query = "insert into studinfo values (?,?,?,?)";
            PreparedStatement ps = con.prepareStatement(query);
            System.out.println("Enter Roll No. of Student: ");
            int roll = sc.nextInt();
            System.out.println("Enter Name of Student: ");
            String name = sc.next();
            System.out.println("Enter Age of Student: ");
            int age = sc.nextInt();
            System.out.println("Enter Path of Image of Student: ");
            String path = sc.next();
            InputStream in = new FileInputStream(path);
            ps.setInt(1,roll);
            ps.setString(2,name);
            ps.setInt(3,age);
            ps.setBinaryStream(4,in);
            int count=0;
            count = ps.executeUpdate();
            System.out.println(count+" rows Affected!!!");
            
            System.out.println("Displaying Data from Database:-");   
            query = "select * from studinfo where roll = ?";
            PreparedStatement ps1 = con.prepareStatement(query);
            System.out.print("Enter Roll No. of Student: ");
            roll = sc.nextInt();
            ps1.setInt(1,roll);
            ResultSet rs = ps1.executeQuery();
            if(rs.next() != false)
            {
                roll = rs.getInt(1);
                name = rs.getString(2);
                age = rs.getInt(3);
                in = rs.getBinaryStream(4);
                System.out.println("Rollno-"+roll+"Name-"+name+"Age-"+age);
             }
             else
             {
                System.out.println("Data Not Found!!!");
             }
        }
    }
}
