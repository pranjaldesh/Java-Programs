import java.sql.DriverManager;
import java.sql.Connection;
class Demo
{
  public static void main(String args[])throws Exception
  {
	com.mysql.cj.jdbc.Driver obj=new com.mysql.cj.jdbc.Driver();
	DriverManager.registerDriver(obj);
	Connection con=null;
	con=DriverManager.getConnection("jdbc:mysql:///","root","pranjal123");
	if(con==null)
	{
	  System.out.println("Connection Not Established");
	}
	else
	{
	  System.out.println("Connection Established");
	}
  }
}