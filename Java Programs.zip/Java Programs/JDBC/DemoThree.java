import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.Scanner;

class DemoThree
{
 public static void main(String args[]) throws Exception
 {
   com.mysql.cj.jdbc.Driver obj = new com.mysql.cj.jdbc.Driver();
		
   DriverManager.registerDriver(obj);
   Connection con = null;
   con = DriverManager.getConnection("jdbc:mysql://localhost:3306/stud","root","pranjal123");
		
   if(con == null)
   {
   System.out.println("Not Established");			
   }
   else
   {
   Statement st = con.createStatement();
   String query ="select * from stud";
   ResultSet rs = st.executeQuery(query);
   
   while(rs.next() != false)
   {
   System.out.println( rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getFloat(4));
   }
   System.out.println();
   Scanner sc=new Scanner(System.in);
   String sc=sc.next();
   Query="SELECT* from stud WHERE sname=+"s"";
   rs=st.executeQuery(Query);
   while(rs.next() != false)
   {
   System.out.println( rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getFloat(4));
   }
   }
}
}
