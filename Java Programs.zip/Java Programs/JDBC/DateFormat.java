import com.mysql.cj.jdbc.Driver;
import java.util.Scanner;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;

class DateFormat
{
	public static void main(String args[])throws Exception
	{
	Class.forName("com.mysql.cj.jdbc.Driver");
	Connection con = null;
        ResultSet rs = null;
	PreparedStatement pst = null;
	Scanner Sc = new Scanner(System.in);
	con = DriverManager.getConnection("jdbc:mysql://localhost:3306/datef","root","pranjal123");
	String query="INSERT INTO FORMAT VALUE(?, ?, ?)";
	pst= con.prepareStatement(query); 
	
	System.out.println("Enter Student Information:-");
	System.out.println("Enter Student Id:-");
	int sid = Sc.nextInt();
	System.out.println("Enter The Name:-");
	String sname = Sc.next();
	System.out.println("Enter The DateOfBirth:-");
	String sdob = Sc.next();
					
	SimpleDateFormat sdf=new SimpleDateFormat("dd-mm-yyyy");
	java.util.Date jdate=sdf.parse(sdob);//converting string into date format(parse method return type java.util.Date)
	System.out.println(jdate);
	long ms=jdate.getTime();//getTime() method returns the miliseconds
	java.sql.Date sdate=new java.sql.Date(ms);//converting java date format into sql data format
	System.out.println(sdate);
	
	pst.setInt(1,sid);
	pst.setString(2,sname);
	pst.setDate(3,sdate);
	
	int count=pst.executeUpdate();
	if(count==1)
	{
	System.out.println("Record Inserted Succesfully....\n");
	}
	else
	{
	System.out.println("Record Not Inserted....\n");
	}
     }
 }