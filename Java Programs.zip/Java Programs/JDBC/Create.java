import com.mysql.cj.jdbc.Driver;
import java.util.Scanner;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.DriverManager;
import java.sql.Statement;

class Create
{
	public static void main(String args[])throws Exception
	{
	int choice,count;
	String query = "";
	String dbname = "";
	String tname = "";
	Class.forName("com.mysql.cj.jdbc.Driver");
	Connection con = null;
	Statement St = null;
	ResultSet Rs = null;
	Scanner Sc = new Scanner(System.in);

	  con = DriverManager.getConnection("jdbc:mysql://localhost:3306/","root","pranjal123");
	  St = con.createStatement();
	  if(con == null)
	  {
	  System.out.println("Connection Not Established !!!");
	  }
	  else
	  {
	  System.out.println("Enter The DataBase Name:-");
	  dbname = Sc.next();
	  query = "CREATE DATABASE "+dbname;
	  count = St.executeUpdate(query);
	  if(count > 0)
	  {
	  System.out.println("DataBase Created Succesfully !!!");
	  query = "USE "+dbname;
	  St.executeUpdate(query);
	  System.out.println("DataBase Changed !!!");
							
	  System.out.println("Enter Table Name:-");
	  tname = Sc.next();
	  query = "CREATE TABLE "+tname+"(sid int primary key, sname varchar(20), sper float)";
	  St.executeUpdate(query);
	  System.out.println("Table Created Succesfully !!!\n");
	  }
	  }
	}
}