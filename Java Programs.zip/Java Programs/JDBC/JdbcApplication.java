import java.sql.DriverManager;
import java.sql.Conncetion;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.Scanner;
class JdbcApplication
{
  public static void main(String args[]) throws Exception
  {
	Connection con=null;
        Statement st=null;
	ResultSet rs=null;
        Scanner sc=null;
        String query= "";
	con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Applications","root","pranjal123");
	st=con.CreateStatement;
	sc=new Scanner(System.in);
	
	System.out.println("Enter Student Username:-");
	String username=sc.next();

	System.out.println("Enter Student Password:-");
	String password=sc.next();
	 
	query="select count(0) from user where username='"+username+"' and password='"+password+"'";
	rs=st.executeQuery(query);

	int count=0;
	while(rs.next())
	{
	count=rs.getInt(1);

        if(count>0)
	{
	System.out.println("User logined Successfully");
	}
	else
	{
	System.out.println("Invalid username or password");
	}
        }
     }