import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;
class JdbcLoginApplication
{
 public static void main(String args[]) throws Exception
  {
	String query;
	Class.forName("com.mysql.cj.jdbc.Driver");
	Connection con = null;
	con = DriverManager.getConnection("jdbc:mysql://localhost:3306/user","root","pranjal123");
	ResultSet rs = null;
	Statement st = con.createStatement();
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter the Username:-");
	String username = sc.nextLine();
	System.out.println("Enter the Password:-");
	String password = sc.nextLine();
	query = "SELECT count(0) From client WHERE username='"+username+"' and password='"+password+"'";
	rs = st.executeQuery(query);
	rs.next();
	int count = rs.getInt(1);
	if(count == 1)
	{
	  System.out.println("Login Successful....");
	}
	else
	{
	  System.out.println("Invalide Username Or Password....");
	}
     }
}