class Print
{
public static void main(String args[])
{
int i;
int n=args.length;
for(i=0;i<n;i++)
{
System.out.println(args[i]);
}
}
}