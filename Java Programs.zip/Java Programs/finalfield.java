class FinalField
{
final int a;
FinalField(int a)
{
this.a=a;
System.out.println("a="+a);
}
public static void main(String args[])
{
FinalField ff=new FinalField(10);
} 
}
