import com.online.on.PackageDemo;
class PackageTest
{
public static void main(String args[])
{
PackageDemo.main(null);
}
}