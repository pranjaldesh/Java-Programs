package com.tcs1.employee;
public class Package
{
public static void main(String args[])
{
NonPackage.main(null);
}
}