abstract class Demo
{
void fun()
{
System.out.println("Hello Parent");
}
abstract void gun();
}
class Test extends Demo
{
void gun()
{
System.out.println("Hello Child");
}
public static void main(String args[])
{
Test t=new Test();
t.fun();
t.gun();
}
}