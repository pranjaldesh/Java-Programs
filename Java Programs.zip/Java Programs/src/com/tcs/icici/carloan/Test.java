package com.tcs.icici.carloan;

import com.tcs.icici.homeloan.Demo;

class Test
{
   public static void main(String args[])
   {
	Demo.main(null);
   }
}