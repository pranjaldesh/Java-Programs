package com.online.on;
class PackageDemo
{
public static void main(String args[])
{
System.out.println("PackageDemo");
}
}
