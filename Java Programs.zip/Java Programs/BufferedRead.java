import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
class BufferedRead
{
public static void main(String args[]) throws IOException
{
BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
System.out.print("Enter Name=");
String n=br.readLine();
System.out.println(n);

System.out.print("Enter RollNo.=");
String r=br.readLine();
System.out.println(r);

System.out.print("Enter Address=");
String a=br.readLine();
System.out.println(a);
}
}
