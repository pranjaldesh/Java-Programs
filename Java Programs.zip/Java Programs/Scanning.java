//Problem of next and nextline
import java.util.Scanner;
class Scanning
{
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
System.out.println("Enter Name=");
String n=sc.next();
System.out.println(n);
System.out.println("Enter Name=");
String m=sc.nextLine();
System.out.println(m);

}
}