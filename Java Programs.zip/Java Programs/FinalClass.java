final class FinalClass
{
void fun()
{
System.out.println("Fun Parent");
}
}
class FinalClass1 extends FinalClass
{
void fun()
{
System.out.println("Fun Child");
}
public static void main(String args[])
{
FinalClass1 fc=new FinalClass1();
fc.fun();
}
}