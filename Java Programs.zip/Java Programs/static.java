class Static
{
static int a=2;
static int x=fun();
static
{
System.out.println("Pranjal");
}
static int fun()
{
return 2;
}
static int gun()
{
return 22;
}
static int b=gun();
static 
{
System.out.println("AVCOE");
}
public static void main(String args[])
{
Static1 st=new Static1();
st.sun();
System.out.println(a);
System.out.println(x);
System.out.println(b);
}
}

