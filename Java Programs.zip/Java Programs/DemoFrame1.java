class DemoFrame1
{
	DemoFrame()
	{
	Javax.Swing.JFrame frame=new Javax.Swing.Jframe();
	}
}
class TestFrame
{
	public static void main(String args[])
	{
	DemoFrame f=new DemoFrame();
	}
}